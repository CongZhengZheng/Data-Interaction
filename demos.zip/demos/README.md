This demo demonstrates the three kind of crimes happening in Chicago in 2023.

The url for the demo is here: https://chi-crime-2023.netlify.app/
